package com.example.cc206_unit6

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
